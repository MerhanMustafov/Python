class Food:
    def __init__(self, expiration_date:int):
        self.expiration_date = expiration_date