
class Player:
    def __init__(self, name: str, hp: int, mp: int)
        self.name = name
        self.hp = hp
        self.mp = mp
        self.skills = 
        self.guild = "Unaffiliated" 