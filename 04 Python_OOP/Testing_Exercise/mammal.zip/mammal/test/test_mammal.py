#
# import unittest
#
# from project.mammal import Mammal
#
#
# class MammalTests(unittest.TestCase):
#     def setUp(self):
#         self.mammal = Mammal("bob", "dog", "bau_bau")
#
#
#     def test_init_creates_all_attributes(self):
#         self.assertEqual(self.mammal.name, 'bob')
#         self.assertEqual(self.mammal.type, 'dog')
#         self.assertEqual(self.mammal.sound, 'bau_bau')
#
#
#     def test_make_sound(self):
#         makes_sound = self.mammal.make_sound()
#         self.assertEqual(makes_sound, f"bob makes bau_bau")
#
#     def test_get_kingdom(self):
#         get_kingdom = self.mammal.get_kingdom()
#         self.assertEqual(get_kingdom, "animals")
#
#     def test_info(self):
#         info = self.mammal.info()
#         self.assertEqual(info, f"bob is of type dog")
#
#     def test_kingdom(self):
#         self.assertEqual(self.mammal._Mammal__kingdom, "animals")

import unittest
from project.mammal import Mammal

class TestMammal(unittest.TestCase):
    def setUp(self):
        self.mammal = Mammal("Test",  "dog",  "woof")
        self.assertEqual("Test", self.mammal.name)
        self.assertEqual("dog", self.mammal.type)
        self.assertEqual("woof", self.mammal.sound)
        self.assertEqual("animals", self.mammal._Mammal__kingdom)


    def test_make_sound(self):
        actual_result = self.mammal.make_sound()
        expected_result = "Test makes woof"
        self.assertEqual(expected_result, actual_result)

    def test_get_kingdom(self):
        actual_result = self.mammal.get_kingdom()
        expected_result = "animals"
        # Assert
        self.assertEqual(expected_result, actual_result)

    def test_info(self):
        actual_result = self.mammal.info()
        expected_result = "Test is of type dog"
        self.assertEqual(expected_result, actual_result)

if __name__ == "__main__":
    unittest.main()